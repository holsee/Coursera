



package object suggestions {

  def log(x: Any) = println(x)

}