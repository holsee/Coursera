package suggestions

import scala.swing.Reactions.Reaction

package object gui {

  object Reaction {
    def apply(r: Reaction) = r
  }

}